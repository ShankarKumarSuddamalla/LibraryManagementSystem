package com.tcs.lms.services;

import java.util.Iterator;
import java.util.List;

import org.springframework.stereotype.Service;

import com.tcs.lms.models.Book;
import com.tcs.lms.repository.LibraryRepository;

@Service
public class LibraryServicesImpl implements LibraryServices {
	
	private LibraryRepository libRepo;
	public LibraryServicesImpl(LibraryRepository libRepo) {
		super();
		this.libRepo=libRepo;
	}

	@Override
	public List<Book> displayAllBooks() {
		// TODO Auto-generated method stub
		return libRepo.listOfBooks();
	}

	@Override
	public Book addBook(Book book) {
		// TODO Auto-generated method stub
		libRepo.listOfBooks().add(book);
		return book;
	}

	@Override
	public Book getBookByBookId(int bid) {
		// TODO Auto-generated method stub
		List<Book> books=libRepo.listOfBooks();
		Book book=books.stream()
		     .filter(bk->bk.getBookId().equals(bid))
		     .findFirst()
		     .orElse(null);
		return book;
	}

	@Override
	public Book deleteBookByBookId(int bid) {
		// TODO Auto-generated method stub
		Iterator<Book> iterator=libRepo.listOfBooks().iterator();
		while(iterator.hasNext()) {
			Book book=iterator.next();
			if(book.getBookId().equals(bid)) {
				iterator.remove();
			}
		}
		return null;
	}

	@Override
	public boolean updateBookById(int bid,Book book) {
		// TODO Auto-generated method stub
		Book presentBook=getBookByBookId(bid);
		presentBook.setBookId(bid);
		presentBook.setBookName(book.getBookName());
		presentBook.setBookAuthor(book.getBookAuthor());
		presentBook.setBookPrice(book.getBookPrice());
		
		return true;
	}
	
}

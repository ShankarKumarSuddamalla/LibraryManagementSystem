package com.tcs.lms.repository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.tcs.lms.models.Book;

@Repository
public class LibraryRepository {

	private static List<Book> bookList=new ArrayList<Book>();
	
	static{
		bookList.add(new Book(101,"Java Reference","James Gosling",599.9f));
		bookList.add(new Book(102,"Python Reference","Guido Van Rossum",699.9f));
		bookList.add(new Book(103,"Javascript Reference","Brendan Eich",499.9f));
		bookList.add(new Book(104,"ReactJs Reference","Jordan Walke",399.9f));
		bookList.add(new Book(105,"NodeJs Reference","Ryan Dhal",299.9f));
	};
	
	public List<Book> listOfBooks(){
		return bookList;
	}
}

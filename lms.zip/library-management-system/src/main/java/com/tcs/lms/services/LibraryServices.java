package com.tcs.lms.services;

import java.util.List;

import com.tcs.lms.models.Book;

public interface LibraryServices {
	public List<Book> displayAllBooks();
	public Book addBook(Book book);
	public Book getBookByBookId(int bid);
	public Book deleteBookByBookId(int bid);
	public boolean updateBookById(int bid,Book book);

}

package com.tcs.lms.models;

import java.time.LocalDateTime;

public class ApiError {
	private int status;
	private String message;
	private LocalDateTime time;
	private String name;
	public ApiError() {
		super();
	}
	public ApiError(LocalDateTime time,int status,String name ,String message) {
		super();
		this.time = time;
		this.status = status;
		this.name = name;
		this.message = message;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public LocalDateTime getTime() {
		return time;
	}
	public void setTime(LocalDateTime time) {
		this.time = time;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
}
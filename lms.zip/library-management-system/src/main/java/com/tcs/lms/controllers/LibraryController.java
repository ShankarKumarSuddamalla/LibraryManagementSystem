package com.tcs.lms.controllers;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tcs.lms.exceptions.BookNotFoundException;
import com.tcs.lms.models.Book;
import com.tcs.lms.services.LibraryServicesImpl;

@RestController
@RequestMapping("/api/library")
public class LibraryController {
	private LibraryServicesImpl libServices;

	public LibraryController(LibraryServicesImpl libServices) {
		super();
		this.libServices = libServices;
	}
	
	@GetMapping
	public ResponseEntity<List<Book>> diaplayAllBooks(){
		List<Book> books=libServices.displayAllBooks();
		if(books.isEmpty()) {
			return ResponseEntity.noContent().build();
		}
		else {
			return ResponseEntity.ok(books);
		}
	}
	
	@GetMapping("/{bid}")
	public ResponseEntity<Book> getBookByBookId(@PathVariable Integer bid){
		Book book=libServices.getBookByBookId(bid);
		if(book==null) {
			throw new BookNotFoundException("Book with BookId: "+bid+" is not in Stock");
		}
		else {
			return ResponseEntity.ok(book);
		}
	}
	
	@PostMapping
	public ResponseEntity<Book> addBook(@RequestBody Book book){
		Book savedBook=libServices.addBook(book);
		return ResponseEntity.ok(book);
	}
	
	@DeleteMapping("/{bid}")
	public ResponseEntity<Book> deleteBookByBookId(@PathVariable Integer bid){
		Book deletedBook=libServices.deleteBookByBookId(bid);
		return ResponseEntity.ok(deletedBook);
	}
	
	@PutMapping("/{bid}")
	public ResponseEntity<String> updateBookByBookId(@PathVariable Integer bid,@RequestBody Book book){
	    boolean val=libServices.updateBookById(bid,book);
	    if(val) {
	    	return ResponseEntity.ok("<h1>Successfully Updated</h1>");
	    }
	    else {
	    	return ResponseEntity.ok("<h1>Book not Updated</h1>");
	    }
	}
}

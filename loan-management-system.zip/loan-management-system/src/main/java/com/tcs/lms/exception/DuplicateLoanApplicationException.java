package com.tcs.lms.exception;

public class DuplicateLoanApplicationException {

}

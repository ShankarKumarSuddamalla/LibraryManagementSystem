package com.tcs.lms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tcs.lms.entity.Loan;
import com.tcs.lms.exception.InvalidLoanAmountException;
import com.tcs.lms.repository.LoanRepository;
@Service
public class LoanServiceImpl implements LoanService {
	
	private LoanRepository loanRepo;
	@Autowired
	public LoanServiceImpl(LoanRepository loanRepo) {
		super();
		this.loanRepo=loanRepo;
	}

	@Override
	public List<Loan> showAllLoans() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Loan getLoanById(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Loan updateLoanById(Long id, String status) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Loan createNewLoan(Loan loan) {
		// TODO Auto-generated method stub
		if(loan.getLoanAmount()<=0 || loan.getLoanAmount()>=5000000)
		{
			throw new InvalidLoanAmountException("Loan Amount must be between 1 and 5000000");
		}

		Loan newLoan=loanRepo.saveLoan(loan);
		return loan;
	}

}

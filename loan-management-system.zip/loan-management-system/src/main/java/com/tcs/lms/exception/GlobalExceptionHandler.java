package com.tcs.lms.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandler {
	@ExceptionHandler(InvalidLoanAmountException.class)
	public ResponseEntity<ErrorResponse> handleInvalidLoanAmountException(InvalidLoanAmountException ex){
		return new ResponseEntity<>(new ErrorResponse("InvalidLoanAmountException",ex.getMessage()),HttpStatus.BAD_REQUEST);		
	}
}

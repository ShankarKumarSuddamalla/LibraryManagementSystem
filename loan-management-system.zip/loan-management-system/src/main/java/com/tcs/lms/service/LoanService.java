package com.tcs.lms.service;

import java.util.List;

import com.tcs.lms.entity.Loan;

public interface LoanService {
	public List<Loan> showAllLoans();
	public Loan getLoanById(Long id);
	public Loan updateLoanById(Long id,String status);
	public Loan createNewLoan(Loan loan);
}

package com.tcs.lms.exception;

public class LoanNotFoundException {

}

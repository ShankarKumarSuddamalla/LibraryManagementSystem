package com.tcs.lms.exception;

public class InvalidLoanAmountException extends RuntimeException {
	public InvalidLoanAmountException(String msg) {
		super(msg);
	}
}

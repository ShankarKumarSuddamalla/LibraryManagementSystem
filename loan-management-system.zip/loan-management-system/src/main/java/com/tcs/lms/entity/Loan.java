package com.tcs.lms.entity;

public class Loan {
	private Long id;
	private String applicantName;
	private double loanAmount;
	private String status;
	public Loan() {
		super();
	}
	public Loan(Long id, String applicantName, Float loanAmount, String status) {
		super();
		this.id = id;
		this.applicantName = applicantName;
		this.loanAmount = loanAmount;
		this.status = status;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getApplicantName() {
		return applicantName;
	}
	public void setApplicantName(String applicantName) {
		this.applicantName = applicantName;
	}
	public double getLoanAmount() {
		return loanAmount;
	}
	public void setLoanAmount(double loanAmount) {
		this.loanAmount = loanAmount;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	
}

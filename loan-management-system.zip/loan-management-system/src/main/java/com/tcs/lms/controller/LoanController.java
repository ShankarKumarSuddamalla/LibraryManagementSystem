package com.tcs.lms.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tcs.lms.entity.Loan;
import com.tcs.lms.service.LoanServiceImpl;

@RestController
@RequestMapping("/loans")
public class LoanController {
	private LoanServiceImpl loanService;
	
	
	public LoanController(LoanServiceImpl loanService) {
		super();
		this.loanService = loanService;
	}


	@PostMapping
	public ResponseEntity<Loan> createNewLoan(Loan loan){
		Loan newLoan=loanService.createNewLoan(loan);
		return new ResponseEntity(newLoan,HttpStatus.CREATED);
	}
}

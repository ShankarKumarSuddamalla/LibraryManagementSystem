package com.tcs.lms.repository;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.tcs.lms.entity.Loan;

@Repository
public class LoanRepository {
	private Map<Long,Loan> loanMap=new HashMap<>();
	private Long count=0L;
	
	public Loan saveLoan(Loan loan) {
		loan.setId(++count);
		loanMap.put(loan.getId(), loan);
		return loan;
	}
}

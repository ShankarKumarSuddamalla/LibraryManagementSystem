package com.tcs.lms.services;

import java.util.List;

import com.tcs.lms.entity.Book;

public interface LibraryService {
	public Book getBookByBookId(Integer id);
	public Book createBook(Book book);
	public Book updateBookById(Integer id,String author);
	public List<Book> getAllBooks();
	public void deleteBook(Integer id);
}

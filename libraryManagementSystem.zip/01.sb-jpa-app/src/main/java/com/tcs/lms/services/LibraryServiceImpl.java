package com.tcs.lms.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.tcs.lms.entity.Book;
import com.tcs.lms.repositories.LibraryRepository;


@Service
public class LibraryServiceImpl implements LibraryService{
	private final LibraryRepository libRepo;
	public LibraryServiceImpl(LibraryRepository libRepo) {
		this.libRepo=libRepo;
	}

	@Override
	public Book getBookByBookId(Integer id) {
		// TODO Auto-generated method stub
		return libRepo.findById(id).orElse(null);
	}

	@Override
	public Book createBook(Book book) {
		// TODO Auto-generated method stub
		return libRepo.save(book);
	}

	@Override
	public Book updateBookById(Integer id,String author) {
		// TODO Auto-generated method stub
		Book book=getBookByBookId(id);
		book.setBookAuthor(author);
		return libRepo.save(book);
	}

	@Override
	public List<Book> getAllBooks() {
		// TODO Auto-generated method stub
		return libRepo.findAll();
	}

	@Override
	public void deleteBook(Integer id) {
		// TODO Auto-generated method stub
		Book deleteBook=getBookByBookId(id);
		libRepo.delete(deleteBook);
	}

}

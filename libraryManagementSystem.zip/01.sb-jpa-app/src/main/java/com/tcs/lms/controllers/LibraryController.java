
package com.tcs.lms.controllers;

import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tcs.lms.entity.Book;
import com.tcs.lms.services.LibraryServiceImpl;


@RestController
@RequestMapping("/api")
public class LibraryController {

    private final LibraryServiceImpl libService;

    public LibraryController(LibraryServiceImpl libService) {
        this.libService = libService;
    }

    @GetMapping("/books")
    public ResponseEntity<List<Book>> viewAllBooks() {
        List<Book> books = libService.getAllBooks();
        return ResponseEntity.ok(books);
    }

    @GetMapping("/books/{id}")
    public ResponseEntity<Book> getBookById(@PathVariable Integer id) {
        Book book = libService.getBookByBookId(id);
        if (book == null) {
            return ResponseEntity.notFound().build(); 
        }
        return ResponseEntity.ok(book);
    }

    @PostMapping("/books")
    public ResponseEntity<Book> createBook(@RequestBody Book book) {
        Book savedBook = libService.createBook(book);
        return ResponseEntity.status(201).body(savedBook);
    }
    @PatchMapping("/books/{id}")
    public ResponseEntity<Book> updateBook(@PathVariable Integer id,@RequestBody Map<String,String> requestUpdate){
    	return ResponseEntity.ok(libService.updateBookById(id, requestUpdate.get("authorName")));
    }
    
    @DeleteMapping("/books/{id}")
    public ResponseEntity<Book> deleteBook(@PathVariable Integer id){
    	libService.deleteBook(id);
    	return new ResponseEntity("Deleted",HttpStatus.GONE);
    }
}

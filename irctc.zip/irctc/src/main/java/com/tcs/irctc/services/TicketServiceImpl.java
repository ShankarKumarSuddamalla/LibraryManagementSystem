package com.tcs.irctc.services;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tcs.irctc.dtos.TicketRequestDTO;
import com.tcs.irctc.entities.Ticket;
import com.tcs.irctc.entities.Train;
import com.tcs.irctc.exceptions.InvalidOperationException;
import com.tcs.irctc.exceptions.ResourceNotFoundException;
import com.tcs.irctc.repositories.TicketRepository;
import com.tcs.irctc.repositories.TrainRepository;

@Service
public  class TicketServiceImpl implements TicketService {

	@Autowired
	private final TicketRepository ticketRepo;
	private final TrainRepository trainRepo;
	public TicketServiceImpl(TicketRepository ticketRepo,TrainRepository trainRepo) {
		this.ticketRepo=ticketRepo;
		this.trainRepo=trainRepo;
	}
	
	
	@Override
	public Ticket bookTicket(TicketRequestDTO requestDTO) {
		// TODO Auto-generated method stub
		if(requestDTO.getTravelDate().isBefore(LocalDate.now())) {
			throw new InvalidOperationException("Travel Date Cannot be past");
		}
		Train train=trainRepo.findById(requestDTO.getTrainId()).orElseThrow(()->new ResourceNotFoundException("Train not Found"));
		
		if(!train.getSource().equalsIgnoreCase(requestDTO.getSource()) || !train.getDestination().equalsIgnoreCase(requestDTO.getDestination())) {
			throw new InvalidOperationException("Invalid route");
		}
		
		if(train.getAvailableSeats()<=0) {
			throw new InvalidOperationException("No Seats Available");
		}
		
		double fare;
		switch(requestDTO.getSeatType().toUpperCase()) {
		case "AC":
			fare=train.getAcFare();
			break;
		case "NON-AC":
			fare=train.getNonAcFare();
			break;
		case "SLEEPER":
			fare=train.getSleeperFare();
			break;
		default:
			throw new InvalidOperationException("Invalid Seat Type");
		}
		
		if("TATKAL".equalsIgnoreCase(requestDTO.getBookingType())) {
			fare +=fare*0.25;
		}
		
		
		train.setAvailableSeats(train.getAvailableSeats()-1);
		trainRepo.save(train);
		
		Ticket ticket = new Ticket();
        ticket.setPassengerName(requestDTO.getPassengerName());
        ticket.setEmail(requestDTO.getEmail());
        ticket.setTrainId(requestDTO.getTrainId());
        ticket.setSource(requestDTO.getSource());
        ticket.setDestination(requestDTO.getDestination());
        ticket.setSeatType(requestDTO.getSeatType());
        ticket.setBookingType(requestDTO.getBookingType());
        ticket.setFare(fare);
        ticket.setTravelDate(requestDTO.getTravelDate());
        ticket.setStatus("BOOKED");
        ticket.setHighFareTicket(fare > 2000);
        ticket.setCreatedAt(LocalDateTime.now());
        ticket.setUpdatedAt(LocalDateTime.now());

        return ticketRepo.save(ticket);
	}

	@Override
	public List<Ticket> getAllTickets() {
		// TODO Auto-generated method stub
		return ticketRepo.findByIsDeletedFalse();
	}

	@Override
	public Ticket getTicketById(Long id) {
		
		return ticketRepo.findById(id).filter(t->!t.getIsDeleted()).orElseThrow(()-> new ResourceNotFoundException("Ticket Not Found"));
	}

    @Override
    public Ticket cancelTicket(Long id) {
        Ticket ticket = getTicketById(id);

        if ("COMPLETED".equals(ticket.getStatus())) {
            throw new InvalidOperationException("Completed ticket cannot be cancelled");
        }

        Train train = trainRepo.findById(ticket.getTrainId()).get();
        train.setAvailableSeats(train.getAvailableSeats() + 1);
        trainRepo.save(train);
        ticket.setStatus("CANCELLED");
        ticket.setIsDeleted(true);
        ticket.setUpdatedAt(LocalDateTime.now());

        return ticketRepo.save(ticket);
    }

    @Override
    public Ticket restoreTicket(Long id) {
        Ticket ticket = ticketRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Ticket not found"));

        ticket.setIsDeleted(false);
        ticket.setStatus("BOOKED");
        ticket.setUpdatedAt(LocalDateTime.now());

        return ticketRepo.save(ticket);
    }

    @Override
    public List<Ticket> search(String name, String email, Long trainId, LocalDate date) {
        if (name != null) return ticketRepo.findByPassengerNameContainingIgnoreCaseAndIsDeletedFalse(name);
        if (email != null) return ticketRepo.findByEmailAndIsDeletedFalse(email);
        if (trainId != null) return ticketRepo.findByTrainIdAndIsDeletedFalse(trainId);
        if (date != null) return ticketRepo.findByTravelDateAndIsDeletedFalse(date);
        return getAllTickets();
    }

    @Override
    public List<Ticket> highFareTickets() {
        return ticketRepo.findByHighFareTicketTrueAndIsDeletedFalse();
    }
}
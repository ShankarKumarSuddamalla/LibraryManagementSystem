package com.tcs.irctc.services;

import java.time.LocalDate;
import java.util.List;

import com.tcs.irctc.dtos.TicketRequestDTO;
import com.tcs.irctc.entities.Ticket;

public interface TicketService {

    public Ticket bookTicket(TicketRequestDTO requestDTO);
    public List<Ticket> getAllTickets();
    public Ticket getTicketById(Long id);
    public Ticket cancelTicket(Long id);
    public List<Ticket> search(String name,String email,Long trainId,LocalDate date);
    public List<Ticket> highFareTickets();
	Ticket restoreTicket(Long id);
  
}

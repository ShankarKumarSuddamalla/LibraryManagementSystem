package com.tcs.irctc.dtos;

public class TicketResponseDTO {
	private Long id;
	private String passengerName;
	private String source;
	private String destination;
	private Double fare;
	private String status;
	private Boolean highFareTicket;
	public TicketResponseDTO(Long id, String passengerName, String source, String destination, Double fare,
			String status, Boolean highFareTicket) {
		super();
		this.id = id;
		this.passengerName = passengerName;
		this.source = source;
		this.destination = destination;
		this.fare = fare;
		this.status = status;
		this.highFareTicket = highFareTicket;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getPassengerName() {
		return passengerName;
	}
	public void setPassengerName(String passengerName) {
		this.passengerName = passengerName;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public Double getFare() {
		return fare;
	}
	public void setFare(Double fare) {
		this.fare = fare;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Boolean getHighFareTicket() {
		return highFareTicket;
	}
	public void setHighFareTicket(Boolean highFareTicket) {
		this.highFareTicket = highFareTicket;
	}
	
}

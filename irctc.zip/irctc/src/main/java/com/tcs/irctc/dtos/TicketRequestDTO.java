package com.tcs.irctc.dtos;

import java.time.LocalDate;

public class TicketRequestDTO {
	private String passengerName;
	private String email;
	private Long trainId;
	private String source;
	private String destination;
	private String seatType;
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	private String bookingType;
	private LocalDate travelDate;
	public TicketRequestDTO(String passengerName, String email, Long trainId, String seatType, String bookingType,
			LocalDate travelDate) {
		super();
		this.passengerName = passengerName;
		this.email = email;
		this.trainId = trainId;
		this.seatType = seatType;
		this.bookingType = bookingType;
		this.travelDate = travelDate;
	}
	public String getPassengerName() {
		return passengerName;
	}
	public void setPassengerName(String passengerName) {
		this.passengerName = passengerName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Long getTrainId() {
		return trainId;
	}
	public void setTrainId(Long trainId) {
		this.trainId = trainId;
	}
	public String getSeatType() {
		return seatType;
	}
	public void setSeatType(String seatType) {
		this.seatType = seatType;
	}
	public String getBookingType() {
		return bookingType;
	}
	public void setBookingType(String bookingType) {
		this.bookingType = bookingType;
	}
	public LocalDate getTravelDate() {
		return travelDate;
	}
	public void setTravelDate(LocalDate travelDate) {
		this.travelDate = travelDate;
	}
	
}

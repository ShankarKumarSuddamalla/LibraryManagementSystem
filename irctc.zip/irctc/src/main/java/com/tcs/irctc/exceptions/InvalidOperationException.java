package com.tcs.irctc.exceptions;

public class InvalidOperationException extends RuntimeException{
	public InvalidOperationException(String msg) {
		super(msg);
	}
}

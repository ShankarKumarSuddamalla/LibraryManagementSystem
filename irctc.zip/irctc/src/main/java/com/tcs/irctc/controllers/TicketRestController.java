package com.tcs.irctc.controllers;

import java.time.LocalDate;
import java.util.List;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.tcs.irctc.dtos.TicketRequestDTO;
import com.tcs.irctc.entities.Ticket;
import com.tcs.irctc.repositories.TrainRepository;
import com.tcs.irctc.services.TicketService;

@RestController
@RequestMapping("/tickets")
public class TicketRestController {

    private final TicketService service;
    private final TrainRepository trainRepo;

    public TicketRestController(TicketService service, TrainRepository trainRepo) {
        this.service = service;
        this.trainRepo = trainRepo;
    }

    @PostMapping
    public Ticket book(@RequestBody TicketRequestDTO dto) {
        return service.bookTicket(dto);
    }

    @GetMapping
    public List<Ticket> all() {
        return service.getAllTickets();
    }

    @GetMapping("/{id}")
    public Ticket get(@PathVariable Long id) {
        return service.getTicketById(id);
    }

    @DeleteMapping("/{id}")
    public Ticket cancel(@PathVariable Long id) {
        return service.cancelTicket(id);
    }

    @PutMapping("/{id}/restore")
    public Ticket restore(@PathVariable Long id) {
        return service.restoreTicket(id);
    }

    @GetMapping("/search")
    public List<Ticket> search(
            @RequestParam(required = false) String name,
            @RequestParam(required = false) String email,
            @RequestParam(required = false) Long trainId,
            @RequestParam(required = false) LocalDate date) {
        return service.search(name, email, trainId, date);
    }

    @GetMapping("/high-fare")
    public List<Ticket> highFare() {
        return service.highFareTickets();
    }

    @GetMapping("/date")
    public List<Ticket> byDate(@RequestParam LocalDate date) {
        return service.search(null, null, null, date);
    }

    @GetMapping("/trains")
    public Object trains() {
        return trainRepo.findAll();
    }
}
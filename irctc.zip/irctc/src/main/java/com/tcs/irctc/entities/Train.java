package com.tcs.irctc.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table
public class Train {
    @Id
    private Long trainId;
    private String source;
    private String destination;
    private double acFare;
    private double nonAcFare;
    private double sleeperFare;
    private int availableSeats;
    
    
	public Train() {
		super();
	}
	public Long getTrainId() {
		return trainId;
	}
	public void setTrainId(Long trainId) {
		this.trainId = trainId;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public double getAcFare() {
		return acFare;
	}
	public void setAcFare(double acFare) {
		this.acFare = acFare;
	}
	public double getNonAcFare() {
		return nonAcFare;
	}
	public void setNonAcFare(double nonAcFare) {
		this.nonAcFare = nonAcFare;
	}
	public double getSleeperFare() {
		return sleeperFare;
	}
	public void setSleeperFare(double sleeperFare) {
		this.sleeperFare = sleeperFare;
	}
	public int getAvailableSeats() {
		return availableSeats;
	}
	public void setAvailableSeats(int availableSeats) {
		this.availableSeats = availableSeats;
	}

    // Getters and Setters
    
}

package com.tcs.irctc.repositories;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tcs.irctc.entities.Ticket;

public interface TicketRepository extends JpaRepository<Ticket, Long> {

    List<Ticket> findByIsDeletedFalse();

    List<Ticket> findByPassengerNameContainingIgnoreCaseAndIsDeletedFalse(String name);

    List<Ticket> findByEmailAndIsDeletedFalse(String email);

    List<Ticket> findByTrainIdAndIsDeletedFalse(Long trainId);

    List<Ticket> findByTravelDateAndIsDeletedFalse(LocalDate date);

    List<Ticket> findByHighFareTicketTrueAndIsDeletedFalse();
}
package com.tcs.irctc.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tcs.irctc.entities.Train;

public interface TrainRepository extends JpaRepository<Train,Long> {

}
